-- Databricks notebook source
CREATE DATABASE IF NOT EXISTS f1_presentation 
LOCATION "/mnt/formula1dl/presentation"

-- COMMAND ----------

